import pyautogui
import time
import cv2
import PIL


def click(path, mode: str, horizontal=0, vertical=0):
    if pyautogui.locateOnScreen(path, confidence=0.8):
        time.sleep(1)  # 等待 1 秒
        left, top, width, height = pyautogui.locateOnScreen(path, confidence=0.8)  # 寻找图标；
        center = pyautogui.center((left + horizontal, top + vertical, width, height))  # 寻找图标的中心
        if mode == 'double_click':
            pyautogui.doubleClick(center)  # 双击
            print('双击成功！')
        elif mode == 'single_click':
            pyautogui.click(center)  # 单击
            print('单击成功！')


def simu_click(path, mode: str, horizontal=0, vertical=0):
    if pyautogui.locateOnScreen(path, confidence=0.8):
        time.sleep(1)  # 等待 1 秒
        left, top, width, height = pyautogui.locateOnScreen(path, confidence=0.8)  # 寻找图标；
        pyautogui.moveTo(left + int(width / 2) + horizontal, top + int(height / 2) + vertical, duration=1)
        if mode == 'double_click':
            pyautogui.mouseDown()  # 鼠标按下
            pyautogui.mouseUp()  # 鼠标释放
            pyautogui.mouseDown()  # 鼠标按下
            pyautogui.mouseUp()  # 鼠标释放
            print('双击成功！')
        elif mode == 'single_click':
            pyautogui.mouseDown()  # 鼠标按下
            pyautogui.mouseUp()  # 鼠标释放
            print('单击成功！')


def open_live():
    click('huya.png', 'double_click')
    while 1:
        if pyautogui.locateOnScreen('next.png', confidence=0.8):
            break
    simu_click('next.png', 'double_click')
    time.sleep(5)
    # simu_click('del.png', 'single_click', 240)
    pyautogui.moveRel(1, 2, duration=1)   # 第一个参数是左右移动像素值，第二个是上下
    pyautogui.mouseDown()  # 鼠标按下
    time.sleep(5)
    click('start.png', 'double_click')
    pyautogui.mouseDown()  # 鼠标按下

