import json
import pyautogui
import time
import threading
import datetime
from datetime import timedelta
import random
from selenium import webdriver
from selenium.webdriver import ActionChains


def click(path, mode: str, horizontal=0, vertical=0):
    if pyautogui.locateOnScreen(path):
        time.sleep(1)  # 等待 1 秒
        left, top, width, height = pyautogui.locateOnScreen(path)  # 寻找图标；
        center = pyautogui.center((left + horizontal, top + vertical, width, height))  # 寻找图标的中心
        if mode == 'double_click':
            pyautogui.doubleClick(center)  # 双击
            print('双击成功！')
        elif mode == 'single_click':
            pyautogui.click(center)  # 单击
            print('单击成功！')


def open_chrome_xingqiong(xingqiong_day):
    #  打开chrome
    option = webdriver.ChromeOptions()
    option.binary_location = r'C:\Program Files\Google\chrome-win64\chrome.exe'
    driver = webdriver.Chrome('C:\Program Files\Google\chrome-win64\chromedriver-win64\chromedriver.exe',
                              options=option)
    driver.get('https://www.huya.com/29088201')
    # 登录模块

    # 获取cookies

    # time.sleep(30)
    # cookies = driver.get_cookies()
    # print(cookies)
    # with open('cookies_3.txt', 'w') as f:
    #     json.dumps(cookies)
    #     f.write(str(json.dumps(cookies)))

    # cookies自动登录
    path = 'cookies_3.txt'
    with open(path, 'r') as f:
        list_cookies = json.loads(f.read())
    for cookie in list_cookies:
        driver.add_cookie(cookie)
    driver.refresh()
    # 进入领取模块
    while 1:
        try:
            btn_1 = driver.find_element_by_xpath('//*[@id="matchComponent3"]/div/div[1]/div/div[2]')
            btn_1.click()
            break
        except Exception as e:
            print(e)
    while 1:
        try:
            btn_2 = driver.find_element_by_xpath('//*[@id="matchComponent12"]/diy/div/div[2]/div')
            btn_2.click()
            break
        except Exception as e:
            print(e)
    d_time = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '2:00', '%Y-%m-%d%H:%M')
    d_time1 = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '23:59', '%Y-%m-%d%H:%M')
    while 1:
        # 当前时间
        n_time = datetime.datetime.now()
        if d_time < n_time < d_time1:
            break
    for k in range(3):
        time.sleep(1)
        for i in range(5):
            while 1:
                try:
                    print('尝试刷新')
                    btn_refresh = driver.find_element_by_xpath('//*[@id="matchComponent25"]/div/div[1]/div[1]/div/div[2]/div['
                                                               '1]/span')
                    btn_refresh.click()
                    print('获取任务奖励')
                    btn_task = driver.find_element_by_xpath(
                        '//*[@id="matchComponent25"]/div/div[1]/div[2]/div/div/ul/li[1]/button')
                    driver.execute_script('arguments[0].click();', btn_task)
                    time.sleep(0.35)
                    try:
                        con_btn = driver.find_element_by_xpath('//*[@id="matchComponent25"]/div[2]/div[2]/button')
                        con_btn.click()
                    except Exception as e:
                        print(e)
                    break
                except Exception as e:
                    print(e)

            while 1:
                try:
                    print('尝试刷新')
                    btn_refresh = driver.find_element_by_xpath('//*[@id="matchComponent25"]/div/div[1]/div[1]/div/div[2]/div['
                                                               '1]/span')
                    btn_refresh.click()
                    xpath = '//*[@id="matchComponent25"]/div/div[1]/div[1]/div/div[2]/div[3]/div[2]/div[1]/ul/li[' + str(
                        xingqiong_day) + ']/p/button'
                    print('尝试获取星琼奖励')
                    xingqiong_btn = driver.find_element_by_xpath(xpath)
                    driver.execute_script('arguments[0].click();', xingqiong_btn)
                    time.sleep(0.3)
                    try:
                        con_btn = driver.find_element_by_xpath('//*[@id="matchComponent25"]/div[2]/div[2]/button')
                        con_btn.click()
                    except Exception as e:
                        print(e)
                    break
                except Exception as e:
                    print(e)
        time.sleep(1)

    time.sleep(5)
    driver.close()
