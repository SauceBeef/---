1.直播和送礼物部分是检测屏幕自动点击的，运行main.py后不要遮挡桌面

2.图像检测置信度0.8参数可以自己改，一直检测不到也可以自己截图替换

3.chromedriver和测试版chrome自己下载，两者需要是对应的版本，然后根据自己的文件路径替换.py中的路径
链接：https://googlechromelabs.github.io/chrome-for-testing/

4.cookies运行get_cookie.py自己手动获取，生命周期七天
# cookies_1/cookies_2/cookies_3 前两个记录送礼物刷弹幕账号 第三个是直播账号

5.js selenium都是0基础自学（甚至算不上学，什么不会搜什么），没啥架构，边想边做的可能很多地方不完善，可以自己修改，有什么好意见也可以一起探讨捏

6.记得改chromedriver网址，别到时候变成给我的直播间刷礼物了