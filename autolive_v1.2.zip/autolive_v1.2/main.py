import threading
import datetime
from datetime import timedelta

from live import open_live
from gift_danmu import multi_thread
import time
from xingqiong import open_chrome_xingqiong


# # 范围时间
# d_time = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '14:30', '%Y-%m-%d%H:%M')
# d_time1 = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '14:50', '%Y-%m-%d%H:%M')
#
# # 判断当前时间是否在范围时间内
# while 1:
#     # 当前时间
#     n_time = datetime.datetime.now()
#     if d_time < n_time < d_time1:
#         print(True)
#         time.sleep(2)
#         open_live()
#         break
#
#
# # 范围时间
# d_time = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '15:30', '%Y-%m-%d%H:%M')
# d_time1 = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '15:50', '%Y-%m-%d%H:%M')
#
# # 判断当前时间是否在范围时间内
# while 1:
#     # 当前时间
#     n_time = datetime.datetime.now()
#     if d_time < n_time < d_time1:
#         print(True)
#         time.sleep(2)
#         multi_thread()
#         break
#
#
# # 范围时间
# d_time = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '17:00', '%Y-%m-%d%H:%M')
# d_time1 = datetime.datetime.strptime(str(datetime.datetime.now().date()) + '17:05', '%Y-%m-%d%H:%M')
#
# # 判断当前时间是否在范围时间内
# while 1:
#     # 当前时间
#     n_time = datetime.datetime.now()
#     if d_time < n_time < d_time1:
#         print(True)
#         time.sleep(2)
#         open_chrome_xingqiong()
#         break
#

# 定时函数 days设置延迟日期
def set_time(function, start, end, days, xingqiong_day=0):
    # 范围时间
    delta = timedelta(days=days)
    d_time = datetime.datetime.strptime(str(datetime.datetime.now().date()) + start, '%Y-%m-%d%H:%M') + delta
    d_time1 = datetime.datetime.strptime(str(datetime.datetime.now().date()) + end, '%Y-%m-%d%H:%M') + delta
    print(f'{d_time}到{d_time1}时启动\n')
    # 判断当前时间是否在范围时间内
    while 1:
        # 当前时间
        n_time = datetime.datetime.now()
        if d_time < n_time < d_time1:
            print(True)
            time.sleep(2)
            if xingqiong_day == 0:
                function()
            else:
                function(xingqiong_day)
            break


class LiveThread(threading.Thread):
    def run(self):
        set_time(open_live, '23:50', '23:59', 0)


class GiftThread(threading.Thread):
    def run(self):
        set_time(multi_thread, '0:10', '1:59', 1)


class StarThread(threading.Thread):
    def run(self):
        set_time(open_chrome_xingqiong, '1:59', '2:00', 1, 1)


threads = []
thread_1 = LiveThread()
thread_2 = GiftThread()
thread_3 = StarThread()
threads.append(thread_1)
threads.append(thread_2)
threads.append(thread_3)

for t in threads:
    t.start()
for t in threads:
    t.join()


