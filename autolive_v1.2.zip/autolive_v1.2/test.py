import threading

from gift_danmu import multi_thread
from live import open_live
import time
import json
from selenium import webdriver
from xingqiong import open_chrome_xingqiong

# 测试直播
# open_live()

# 测试刷弹幕送礼物
# multi_thread()

# 测试领取奖励
# open_chrome_xingqiong(1)

option = webdriver.ChromeOptions()
option.binary_location = r'C:\Program Files\Google\chrome-win64\chrome.exe'
driver = webdriver.Chrome('C:\Program Files\Google\chrome-win64\chromedriver-win64\chromedriver.exe', options=option)
driver.get('https://www.huya.com/29088201')


time.sleep(3)
path = 'cookies_3.txt'
with open(path, 'r') as f:
    list_cookies = json.loads(f.read())
for cookie in list_cookies:
    driver.add_cookie(cookie)
driver.refresh()
driver.maximize_window()
time.sleep(5000)
