import json
import threading
import pyautogui
import time
import random
from selenium import webdriver


def click(path, mode: str, horizontal=0, vertical=0):
    if pyautogui.locateOnScreen(path, confidence=0.8):
        time.sleep(1)  # 等待 1 秒
        left, top, width, height = pyautogui.locateOnScreen(path, confidence=0.8)  # 寻找图标；
        center = pyautogui.center((left + horizontal, top + vertical, width, height))  # 寻找图标的中心
        if mode == 'double_click':
            pyautogui.doubleClick(center)  # 双击
            print('双击成功！')
        elif mode == 'single_click':
            pyautogui.click(center)  # 单击
            print('单击成功！')


def give_gift(path, give: list):
    if pyautogui.locateOnScreen(path):
        # 等待 2 秒
        time.sleep(2)
        click('open.png', 'single_click')
        time.sleep(2)
        for i in range(1):
            click('ygb.png', 'single_click')
            time.sleep(2)
            for j in range(10):
                time.sleep(1)
                if pyautogui.locateOnScreen('cancel.png'):
                    give[0] = 1
                    left, top, width, height = pyautogui.locateOnScreen('cancel.png')  # 寻找图标；
                    pyautogui.moveTo(left + int(width / 2) - 100, top + int(height / 2), duration=1)
                    pyautogui.mouseDown()  # 鼠标按下
                    pyautogui.mouseUp()  # 鼠标释放
                    time.sleep(2)
                    break


def danmu(path):
    # click(path, 'single_click')
    # time.sleep(2)
    if pyautogui.locateOnScreen('danmu.png'):
        time.sleep(2)  # 等待 1 秒
        left, top, width, height = pyautogui.locateOnScreen('danmu.png')  # 寻找图标；
        center = pyautogui.center((left, top, width, height))  # 寻找图标的中心
        pyautogui.click(center)  # 单击

        for i in range(7):
            pyautogui.press('2')
            time.sleep(0.1)
            for j in range(5):
                time.sleep(0.1)
                pyautogui.press('3')
            pyautogui.press('enter')
            time.sleep(10)


def open_chrome(path):
    #  打开chrome
    option = webdriver.ChromeOptions()
    option.binary_location = r'C:\Program Files\Google\chrome-win64\chrome.exe'
    driver = webdriver.Chrome('C:\Program Files\Google\chrome-win64\chromedriver-win64\chromedriver.exe', options=option)
    driver.get('https://www.huya.com/29088201')
    # 登录模块

    # 获取cookies

    # time.sleep(30)
    # cookies = driver.get_cookies()
    # print(cookies)
    # with open('cookies_1.txt', 'w') as f:
    #     json.dumps(cookies)
    #     f.write(str(json.dumps(cookies)))

    # cookies自动登录
    time.sleep(5)
    with open(path, 'r') as f:
        list_cookies = json.loads(f.read())
    for cookie in list_cookies:
        driver.add_cookie(cookie)

    driver.refresh()
    driver.maximize_window()
    give = [0]
    time.sleep(5)
    while 1:
        try:
            input_text = driver.find_element_by_id('pub_msg_input')
            break
        except Exception as e:
            print(e)
    input_text = driver.find_element_by_id('pub_msg_input')
    danmu_list = ['233333333', '太酷啦', '只因jijiji', '小癖好是元神高手', '星穹铁道，启动！', '主播是阮梅的狗吗']
    for i in range(5):
        random_index = random.randint(0, len(danmu_list) - 1)
        input_text.send_keys(danmu_list[random_index])
        time.sleep(1)
        send_btn = driver.find_element_by_id('msg_send_bt')
        send_btn.click()
        time.sleep(2)
    give_gift('open.png', give)
    if give[0] == 0:
        driver.refresh()
        time.sleep(5)
        input_text = driver.find_element_by_id('pub_msg_input')
        random_index = random.randint(0, len(danmu_list) - 1)
        input_text.send_keys(danmu_list[random_index])
        time.sleep(1)
        send_btn = driver.find_element_by_id('msg_send_bt')
        send_btn.click()
        time.sleep(2)
        give_gift('open.png', give)
    time.sleep(400)
    driver.close()


def multi_thread():
    path = ['cookies_1.txt', 'cookies_2.txt']
    for i in range(2):
        open_chrome(path=path[i])
