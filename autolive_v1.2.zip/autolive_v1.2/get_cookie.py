import time
import json
from selenium import webdriver

# 要下载对应版本的测试版chrome和chrome driver
option = webdriver.ChromeOptions()
option.binary_location = r'C:\Program Files\Google\chrome-win64\chrome.exe'
driver = webdriver.Chrome('C:\Program Files\Google\chrome-win64\chromedriver-win64\chromedriver.exe', options=option)
driver.get('https://www.huya.com/29088201')

# 扫码登陆等30秒自动记录cookie 有七天时限
time.sleep(30)
cookies = driver.get_cookies()
print(cookies)
# cookies_1/cookies_2/cookies_3 前两个记录送礼物刷弹幕账号 第三个是直播账号
with open('cookies_1.txt', 'w') as f:
    json.dumps(cookies)
    f.write(str(json.dumps(cookies)))

time.sleep(3)
driver.refresh()
driver.close()